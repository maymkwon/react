import React from "react";
import {render} from "react-dom";

import {Header} from "./components/Header";
import {Home} from "./components/Home";


class App extends React.Component {

    constructor(){
        super();
        this.state ={
            homeLink : "home"
        };
    }
    onGreet(){
        alert('hello');
    }
    onChangeLinkName(newName){
        this.setState({
            homeLink:newName
        });
    }

    render(){
        return(
            <div>
                <div>
                    <Header homeLink={this.state.homeLink}/>
                </div>
                <div>
                    <Home
                    name={"Max"}
                    initialAge={28}
                    greet={this.onGreet}
                    changeLink={this.onChangeLinkName.bind(this)}
                    initialLinkName={this.state.homeLink}

                    />
                </div>
            </div>
        );
    }
}


render(<App/>, window.document.getElementById('app'));
