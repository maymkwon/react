import React from "react";

export const Header = (props) =>{
    return(
        <div>
            <h1>{props.homeLink}</h1>
        </div>
    );
}
