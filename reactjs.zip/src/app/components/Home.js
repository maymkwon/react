import React from "react";

export class Home extends React.Component{
    constructor(props){
        super();
        this.state = {
                age:props.initialAge,
                status: 0,
                homeLink:"change"
        };
        setTimeout(() => {
            this.setState({
                status:1
            });
        },2000);
    }
    onMakeOlder(){
        this.setState({
            age: this.state.age +3
        });
    }
    onChangeLink(){
        this.props.changeLink(this.state.homeLink);
    }

    render(){
        return(
            <div>
                <h1>i am</h1>
                <p>my name is{this.props.name}, {this.state.age}years old!</p>
                <p>status : {this.state.status}</p>
                <button onClick={() => this.onMakeOlder()}>make me older</button>
                <button onClick={this.props.greet}>greet</button>
                <button onClick={this.onChangeLink.bind(this)}>change header link</button>
                <input type="text" value={this.props.initialLinkName}/>
            </div>
        );
    }
}

Home.propTypes ={
    name: React.PropTypes.string,
    initialAge: React.PropTypes.number,
    greet:React.PropTypes.func,
    initialLinkName:React.PropTypes.string
};
